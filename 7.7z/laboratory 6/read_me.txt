Option 1
create_db_option_1.py
app_option_1.py
templates/index.html



Option 2
app_option_2_full.py
musics.db
templates/index_musics.html

